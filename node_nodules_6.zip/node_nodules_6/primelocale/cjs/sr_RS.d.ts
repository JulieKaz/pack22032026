import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale sr_RS.
 */
export declare const sr_RS: Locale;