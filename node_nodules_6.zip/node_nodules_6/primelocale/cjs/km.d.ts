import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale km.
 */
export declare const km: Locale;