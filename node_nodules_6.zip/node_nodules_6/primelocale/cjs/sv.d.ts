import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale sv.
 */
export declare const sv: Locale;