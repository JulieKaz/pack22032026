import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale es.
 */
export declare const es: Locale;