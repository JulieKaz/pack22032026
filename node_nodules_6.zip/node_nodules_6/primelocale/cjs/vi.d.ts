import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale vi.
 */
export declare const vi: Locale;