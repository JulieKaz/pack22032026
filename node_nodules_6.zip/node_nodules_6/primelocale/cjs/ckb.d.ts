import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ckb.
 */
export declare const ckb: Locale;