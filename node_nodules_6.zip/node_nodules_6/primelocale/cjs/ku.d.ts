import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ku.
 */
export declare const ku: Locale;