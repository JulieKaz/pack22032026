import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale en_CA.
 */
export declare const en_CA: Locale;