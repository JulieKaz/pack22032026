import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale en_AU.
 */
export declare const en_AU: Locale;