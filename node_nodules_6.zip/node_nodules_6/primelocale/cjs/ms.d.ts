import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ms.
 */
export declare const ms: Locale;