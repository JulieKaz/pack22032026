import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ca.
 */
export declare const ca: Locale;