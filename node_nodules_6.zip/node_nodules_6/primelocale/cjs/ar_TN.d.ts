import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ar_TN.
 */
export declare const ar_TN: Locale;