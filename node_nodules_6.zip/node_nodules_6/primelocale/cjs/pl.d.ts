import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale pl.
 */
export declare const pl: Locale;