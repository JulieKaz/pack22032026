import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale de_CH.
 */
export declare const de_CH: Locale;