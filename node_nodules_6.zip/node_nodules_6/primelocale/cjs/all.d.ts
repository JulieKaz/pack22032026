import type { Locale } from "./locale.js";

export interface AllLocales {
  /**
   * The localized messages for the language `ar`.
   */
  ar: Locale;
  /**
   * The localized messages for the language `ar_TN`.
   */
  ar_TN: Locale;
  /**
   * The localized messages for the language `ar_TN`.
   */
  "ar-TN": Locale;
  /**
   * The localized messages for the language `bg`.
   */
  bg: Locale;
  /**
   * The localized messages for the language `bn`.
   */
  bn: Locale;
  /**
   * The localized messages for the language `bs`.
   */
  bs: Locale;
  /**
   * The localized messages for the language `ca`.
   */
  ca: Locale;
  /**
   * The localized messages for the language `ckb`.
   */
  ckb: Locale;
  /**
   * The localized messages for the language `cs`.
   */
  cs: Locale;
  /**
   * The localized messages for the language `da`.
   */
  da: Locale;
  /**
   * The localized messages for the language `de`.
   */
  de: Locale;
  /**
   * The localized messages for the language `de_AT`.
   */
  de_AT: Locale;
  /**
   * The localized messages for the language `de_AT`.
   */
  "de-AT": Locale;
  /**
   * The localized messages for the language `de_CH`.
   */
  de_CH: Locale;
  /**
   * The localized messages for the language `de_CH`.
   */
  "de-CH": Locale;
  /**
   * The localized messages for the language `el`.
   */
  el: Locale;
  /**
   * The localized messages for the language `en`.
   */
  en: Locale;
  /**
   * The localized messages for the language `en_AU`.
   */
  en_AU: Locale;
  /**
   * The localized messages for the language `en_AU`.
   */
  "en-AU": Locale;
  /**
   * The localized messages for the language `en_CA`.
   */
  en_CA: Locale;
  /**
   * The localized messages for the language `en_CA`.
   */
  "en-CA": Locale;
  /**
   * The localized messages for the language `en_GB`.
   */
  en_GB: Locale;
  /**
   * The localized messages for the language `en_GB`.
   */
  "en-GB": Locale;
  /**
   * The localized messages for the language `es`.
   */
  es: Locale;
  /**
   * The localized messages for the language `et`.
   */
  et: Locale;
  /**
   * The localized messages for the language `fa`.
   */
  fa: Locale;
  /**
   * The localized messages for the language `fi`.
   */
  fi: Locale;
  /**
   * The localized messages for the language `fr`.
   */
  fr: Locale;
  /**
   * The localized messages for the language `he`.
   */
  he: Locale;
  /**
   * The localized messages for the language `hi`.
   */
  hi: Locale;
  /**
   * The localized messages for the language `hr`.
   */
  hr: Locale;
  /**
   * The localized messages for the language `ht`.
   */
  ht: Locale;
  /**
   * The localized messages for the language `hu`.
   */
  hu: Locale;
  /**
   * The localized messages for the language `id`.
   */
  id: Locale;
  /**
   * The localized messages for the language `is`.
   */
  is: Locale;
  /**
   * The localized messages for the language `it`.
   */
  it: Locale;
  /**
   * The localized messages for the language `ja`.
   */
  ja: Locale;
  /**
   * The localized messages for the language `kk`.
   */
  kk: Locale;
  /**
   * The localized messages for the language `km`.
   */
  km: Locale;
  /**
   * The localized messages for the language `ko`.
   */
  ko: Locale;
  /**
   * The localized messages for the language `ku`.
   */
  ku: Locale;
  /**
   * The localized messages for the language `ky`.
   */
  ky: Locale;
  /**
   * The localized messages for the language `lt`.
   */
  lt: Locale;
  /**
   * The localized messages for the language `lv`.
   */
  lv: Locale;
  /**
   * The localized messages for the language `ms`.
   */
  ms: Locale;
  /**
   * The localized messages for the language `my`.
   */
  my: Locale;
  /**
   * The localized messages for the language `nb_NO`.
   */
  nb_NO: Locale;
  /**
   * The localized messages for the language `nb_NO`.
   */
  "nb-NO": Locale;
  /**
   * The localized messages for the language `nl`.
   */
  nl: Locale;
  /**
   * The localized messages for the language `pl`.
   */
  pl: Locale;
  /**
   * The localized messages for the language `pt`.
   */
  pt: Locale;
  /**
   * The localized messages for the language `pt_BR`.
   */
  pt_BR: Locale;
  /**
   * The localized messages for the language `pt_BR`.
   */
  "pt-BR": Locale;
  /**
   * The localized messages for the language `ro`.
   */
  ro: Locale;
  /**
   * The localized messages for the language `ru`.
   */
  ru: Locale;
  /**
   * The localized messages for the language `sk`.
   */
  sk: Locale;
  /**
   * The localized messages for the language `sl`.
   */
  sl: Locale;
  /**
   * The localized messages for the language `sq`.
   */
  sq: Locale;
  /**
   * The localized messages for the language `sr_RS`.
   */
  sr_RS: Locale;
  /**
   * The localized messages for the language `sr_RS`.
   */
  "sr-RS": Locale;
  /**
   * The localized messages for the language `sv`.
   */
  sv: Locale;
  /**
   * The localized messages for the language `th`.
   */
  th: Locale;
  /**
   * The localized messages for the language `tl`.
   */
  tl: Locale;
  /**
   * The localized messages for the language `tr`.
   */
  tr: Locale;
  /**
   * The localized messages for the language `uk`.
   */
  uk: Locale;
  /**
   * The localized messages for the language `ur`.
   */
  ur: Locale;
  /**
   * The localized messages for the language `uz`.
   */
  uz: Locale;
  /**
   * The localized messages for the language `vi`.
   */
  vi: Locale;
  /**
   * The localized messages for the language `zh_CN`.
   */
  zh_CN: Locale;
  /**
   * The localized messages for the language `zh_CN`.
   */
  "zh-CN": Locale;
  /**
   * The localized messages for the language `zh_TW`.
   */
  zh_TW: Locale;
  /**
   * The localized messages for the language `zh_TW`.
   */
  "zh-TW": Locale;
}

/**
 * An object with all messages for all languages.
 * The key is the language code, the value the messages.
 */
export declare const all: AllLocales;