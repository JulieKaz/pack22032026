import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale th.
 */
export declare const th: Locale;