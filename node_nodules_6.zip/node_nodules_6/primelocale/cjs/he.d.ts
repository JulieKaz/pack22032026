import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale he.
 */
export declare const he: Locale;