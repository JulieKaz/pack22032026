import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale hr.
 */
export declare const hr: Locale;