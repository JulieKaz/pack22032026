import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale zh_CN.
 */
export declare const zh_CN: Locale;