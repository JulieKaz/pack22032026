import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ky.
 */
export declare const ky: Locale;