import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale de.
 */
export declare const de: Locale;