/**
 * Type to which all locales adhere, contains the keys present for each locale.
 */
export interface Locale {
  /**
   * The localized value for the message key `accept`.
   */
  accept: string,
  /**
   * The localized value for the message key `addRule`.
   */
  addRule: string,
  /**
   * The localized value for the message key `am`.
   */
  am: string,
  /**
   * The localized value for the message key `apply`.
   */
  apply: string,
  /**
   * The localized value for the message key `aria`.
   */
  aria: {
    /**
     * The localized value for the message key `cancelEdit`.
     */
    cancelEdit: string,
    /**
     * The localized value for the message key `close`.
     */
    close: string,
    /**
     * The localized value for the message key `collapseLabel`.
     */
    collapseLabel: string,
    /**
     * The localized value for the message key `collapseRow`.
     */
    collapseRow: string,
    /**
     * The localized value for the message key `editRow`.
     */
    editRow: string,
    /**
     * The localized value for the message key `expandLabel`.
     */
    expandLabel: string,
    /**
     * The localized value for the message key `expandRow`.
     */
    expandRow: string,
    /**
     * The localized value for the message key `falseLabel`.
     */
    falseLabel: string,
    /**
     * The localized value for the message key `filterConstraint`.
     */
    filterConstraint: string,
    /**
     * The localized value for the message key `filterOperator`.
     */
    filterOperator: string,
    /**
     * The localized value for the message key `firstPageLabel`.
     */
    firstPageLabel: string,
    /**
     * The localized value for the message key `gridView`.
     */
    gridView: string,
    /**
     * The localized value for the message key `hideFilterMenu`.
     */
    hideFilterMenu: string,
    /**
     * The localized value for the message key `jumpToPageDropdownLabel`.
     */
    jumpToPageDropdownLabel: string,
    /**
     * The localized value for the message key `jumpToPageInputLabel`.
     */
    jumpToPageInputLabel: string,
    /**
     * The localized value for the message key `lastPageLabel`.
     */
    lastPageLabel: string,
    /**
     * The localized value for the message key `listLabel`.
     */
    listLabel: string,
    /**
     * The localized value for the message key `listView`.
     */
    listView: string,
    /**
     * The localized value for the message key `maximizeLabel`.
     */
    maximizeLabel: string,
    /**
     * The localized value for the message key `minimizeLabel`.
     */
    minimizeLabel: string,
    /**
     * The localized value for the message key `moveAllToSource`.
     */
    moveAllToSource: string,
    /**
     * The localized value for the message key `moveAllToTarget`.
     */
    moveAllToTarget: string,
    /**
     * The localized value for the message key `moveBottom`.
     */
    moveBottom: string,
    /**
     * The localized value for the message key `moveDown`.
     */
    moveDown: string,
    /**
     * The localized value for the message key `moveToSource`.
     */
    moveToSource: string,
    /**
     * The localized value for the message key `moveToTarget`.
     */
    moveToTarget: string,
    /**
     * The localized value for the message key `moveTop`.
     */
    moveTop: string,
    /**
     * The localized value for the message key `moveUp`.
     */
    moveUp: string,
    /**
     * The localized value for the message key `navigation`.
     */
    navigation: string,
    /**
     * The localized value for the message key `next`.
     */
    next: string,
    /**
     * The localized value for the message key `nextPageLabel`.
     */
    nextPageLabel: string,
    /**
     * The localized value for the message key `nullLabel`.
     */
    nullLabel: string,
    /**
     * The localized value for the message key `otpLabel`.
     */
    otpLabel: string,
    /**
     * The localized value for the message key `pageLabel`.
     */
    pageLabel: string,
    /**
     * The localized value for the message key `passwordHide`.
     */
    passwordHide: string,
    /**
     * The localized value for the message key `passwordShow`.
     */
    passwordShow: string,
    /**
     * The localized value for the message key `prevPageLabel`.
     */
    prevPageLabel: string,
    /**
     * The localized value for the message key `previous`.
     */
    previous: string,
    /**
     * The localized value for the message key `removeLabel`.
     */
    removeLabel: string,
    /**
     * The localized value for the message key `rotateLeft`.
     */
    rotateLeft: string,
    /**
     * The localized value for the message key `rotateRight`.
     */
    rotateRight: string,
    /**
     * The localized value for the message key `rowsPerPageLabel`.
     */
    rowsPerPageLabel: string,
    /**
     * The localized value for the message key `saveEdit`.
     */
    saveEdit: string,
    /**
     * The localized value for the message key `scrollTop`.
     */
    scrollTop: string,
    /**
     * The localized value for the message key `selectAll`.
     */
    selectAll: string,
    /**
     * The localized value for the message key `selectColor`.
     */
    selectColor: string,
    /**
     * The localized value for the message key `selectLabel`.
     */
    selectLabel: string,
    /**
     * The localized value for the message key `selectRow`.
     */
    selectRow: string,
    /**
     * The localized value for the message key `showFilterMenu`.
     */
    showFilterMenu: string,
    /**
     * The localized value for the message key `slide`.
     */
    slide: string,
    /**
     * The localized value for the message key `slideNumber`.
     */
    slideNumber: string,
    /**
     * The localized value for the message key `star`.
     */
    star: string,
    /**
     * The localized value for the message key `stars`.
     */
    stars: string,
    /**
     * The localized value for the message key `trueLabel`.
     */
    trueLabel: string,
    /**
     * The localized value for the message key `unselectAll`.
     */
    unselectAll: string,
    /**
     * The localized value for the message key `unselectLabel`.
     */
    unselectLabel: string,
    /**
     * The localized value for the message key `unselectRow`.
     */
    unselectRow: string,
    /**
     * The localized value for the message key `zoomImage`.
     */
    zoomImage: string,
    /**
     * The localized value for the message key `zoomIn`.
     */
    zoomIn: string,
    /**
     * The localized value for the message key `zoomOut`.
     */
    zoomOut: string,
  },
  /**
   * The localized value for the message key `cancel`.
   */
  cancel: string,
  /**
   * The localized value for the message key `choose`.
   */
  choose: string,
  /**
   * The localized value for the message key `chooseDate`.
   */
  chooseDate: string,
  /**
   * The localized value for the message key `chooseMonth`.
   */
  chooseMonth: string,
  /**
   * The localized value for the message key `chooseYear`.
   */
  chooseYear: string,
  /**
   * The localized value for the message key `clear`.
   */
  clear: string,
  /**
   * The localized value for the message key `completed`.
   */
  completed: string,
  /**
   * The localized value for the message key `contains`.
   */
  contains: string,
  /**
   * The localized value for the message key `custom`.
   */
  custom: string,
  /**
   * The localized value for the message key `dateAfter`.
   */
  dateAfter: string,
  /**
   * The localized value for the message key `dateBefore`.
   */
  dateBefore: string,
  /**
   * The localized value for the message key `dateFormat`.
   */
  dateFormat: string,
  /**
   * The localized value for the message key `dateIs`.
   */
  dateIs: string,
  /**
   * The localized value for the message key `dateIsNot`.
   */
  dateIsNot: string,
  /**
   * The localized value for the message key `dayNames`.
   */
  dayNames: string[],
  /**
   * The localized value for the message key `dayNamesMin`.
   */
  dayNamesMin: string[],
  /**
   * The localized value for the message key `dayNamesShort`.
   */
  dayNamesShort: string[],
  /**
   * The localized value for the message key `emptyFilterMessage`.
   */
  emptyFilterMessage: string,
  /**
   * The localized value for the message key `emptyMessage`.
   */
  emptyMessage: string,
  /**
   * The localized value for the message key `emptySearchMessage`.
   */
  emptySearchMessage: string,
  /**
   * The localized value for the message key `emptySelectionMessage`.
   */
  emptySelectionMessage: string,
  /**
   * The localized value for the message key `endsWith`.
   */
  endsWith: string,
  /**
   * The localized value for the message key `equals`.
   */
  equals: string,
  /**
   * The localized value for the message key `fileChosenMessage`.
   */
  fileChosenMessage: string,
  /**
   * The localized value for the message key `fileSizeTypes`.
   */
  fileSizeTypes: string[],
  /**
   * The localized value for the message key `filter`.
   */
  filter: string,
  /**
   * The localized value for the message key `firstDayOfWeek`.
   */
  firstDayOfWeek: number,
  /**
   * The localized value for the message key `gt`.
   */
  gt: string,
  /**
   * The localized value for the message key `gte`.
   */
  gte: string,
  /**
   * The localized value for the message key `lt`.
   */
  lt: string,
  /**
   * The localized value for the message key `lte`.
   */
  lte: string,
  /**
   * The localized value for the message key `matchAll`.
   */
  matchAll: string,
  /**
   * The localized value for the message key `matchAny`.
   */
  matchAny: string,
  /**
   * The localized value for the message key `medium`.
   */
  medium: string,
  /**
   * The localized value for the message key `monthNames`.
   */
  monthNames: string[],
  /**
   * The localized value for the message key `monthNamesShort`.
   */
  monthNamesShort: string[],
  /**
   * The localized value for the message key `nextDecade`.
   */
  nextDecade: string,
  /**
   * The localized value for the message key `nextHour`.
   */
  nextHour: string,
  /**
   * The localized value for the message key `nextMinute`.
   */
  nextMinute: string,
  /**
   * The localized value for the message key `nextMonth`.
   */
  nextMonth: string,
  /**
   * The localized value for the message key `nextSecond`.
   */
  nextSecond: string,
  /**
   * The localized value for the message key `nextYear`.
   */
  nextYear: string,
  /**
   * The localized value for the message key `noFileChosenMessage`.
   */
  noFileChosenMessage: string,
  /**
   * The localized value for the message key `noFilter`.
   */
  noFilter: string,
  /**
   * The localized value for the message key `notContains`.
   */
  notContains: string,
  /**
   * The localized value for the message key `notEquals`.
   */
  notEquals: string,
  /**
   * The localized value for the message key `now`.
   */
  now: string,
  /**
   * The localized value for the message key `passwordPrompt`.
   */
  passwordPrompt: string,
  /**
   * The localized value for the message key `pending`.
   */
  pending: string,
  /**
   * The localized value for the message key `pm`.
   */
  pm: string,
  /**
   * The localized value for the message key `prevDecade`.
   */
  prevDecade: string,
  /**
   * The localized value for the message key `prevHour`.
   */
  prevHour: string,
  /**
   * The localized value for the message key `prevMinute`.
   */
  prevMinute: string,
  /**
   * The localized value for the message key `prevMonth`.
   */
  prevMonth: string,
  /**
   * The localized value for the message key `prevSecond`.
   */
  prevSecond: string,
  /**
   * The localized value for the message key `prevYear`.
   */
  prevYear: string,
  /**
   * The localized value for the message key `reject`.
   */
  reject: string,
  /**
   * The localized value for the message key `removeRule`.
   */
  removeRule: string,
  /**
   * The localized value for the message key `searchMessage`.
   */
  searchMessage: string,
  /**
   * The localized value for the message key `selectionMessage`.
   */
  selectionMessage: string,
  /**
   * The localized value for the message key `showMonthAfterYear`.
   */
  showMonthAfterYear: boolean,
  /**
   * The localized value for the message key `startsWith`.
   */
  startsWith: string,
  /**
   * The localized value for the message key `strong`.
   */
  strong: string,
  /**
   * The localized value for the message key `today`.
   */
  today: string,
  /**
   * The localized value for the message key `upload`.
   */
  upload: string,
  /**
   * The localized value for the message key `weak`.
   */
  weak: string,
  /**
   * The localized value for the message key `weekHeader`.
   */
  weekHeader: string,
}