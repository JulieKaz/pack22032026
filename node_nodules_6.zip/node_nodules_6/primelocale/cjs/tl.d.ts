import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale tl.
 */
export declare const tl: Locale;