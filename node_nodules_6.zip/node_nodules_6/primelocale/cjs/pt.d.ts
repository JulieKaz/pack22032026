import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale pt.
 */
export declare const pt: Locale;