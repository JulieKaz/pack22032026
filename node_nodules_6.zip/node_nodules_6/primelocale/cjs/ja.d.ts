import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ja.
 */
export declare const ja: Locale;