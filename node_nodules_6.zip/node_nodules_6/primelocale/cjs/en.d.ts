import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale en.
 */
export declare const en: Locale;