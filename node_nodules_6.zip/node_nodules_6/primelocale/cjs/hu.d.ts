import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale hu.
 */
export declare const hu: Locale;