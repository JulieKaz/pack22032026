import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale is.
 */
export declare const is: Locale;