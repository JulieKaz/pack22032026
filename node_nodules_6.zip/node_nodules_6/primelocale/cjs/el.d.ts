import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale el.
 */
export declare const el: Locale;