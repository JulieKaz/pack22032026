import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale en_GB.
 */
export declare const en_GB: Locale;