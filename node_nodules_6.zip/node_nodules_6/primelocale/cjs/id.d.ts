import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale id.
 */
export declare const id: Locale;