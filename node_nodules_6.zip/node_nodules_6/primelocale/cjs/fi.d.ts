import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale fi.
 */
export declare const fi: Locale;