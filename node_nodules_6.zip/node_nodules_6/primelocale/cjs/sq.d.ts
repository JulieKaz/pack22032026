import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale sq.
 */
export declare const sq: Locale;