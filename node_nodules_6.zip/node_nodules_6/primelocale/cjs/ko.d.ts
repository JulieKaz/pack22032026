import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ko.
 */
export declare const ko: Locale;