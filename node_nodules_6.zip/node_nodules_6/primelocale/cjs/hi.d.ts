import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale hi.
 */
export declare const hi: Locale;