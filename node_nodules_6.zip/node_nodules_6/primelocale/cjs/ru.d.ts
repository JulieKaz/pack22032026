import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ru.
 */
export declare const ru: Locale;