import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale zh_TW.
 */
export declare const zh_TW: Locale;