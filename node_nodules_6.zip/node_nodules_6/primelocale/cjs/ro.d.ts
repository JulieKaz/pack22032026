import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ro.
 */
export declare const ro: Locale;