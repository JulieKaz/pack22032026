import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale kk.
 */
export declare const kk: Locale;