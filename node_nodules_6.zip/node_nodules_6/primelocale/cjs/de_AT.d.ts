import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale de_AT.
 */
export declare const de_AT: Locale;