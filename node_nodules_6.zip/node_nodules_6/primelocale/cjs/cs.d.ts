import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale cs.
 */
export declare const cs: Locale;