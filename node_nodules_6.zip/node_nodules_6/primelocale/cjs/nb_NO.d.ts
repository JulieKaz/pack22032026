import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale nb_NO.
 */
export declare const nb_NO: Locale;