import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale fa.
 */
export declare const fa: Locale;