import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale uz.
 */
export declare const uz: Locale;