import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale lt.
 */
export declare const lt: Locale;