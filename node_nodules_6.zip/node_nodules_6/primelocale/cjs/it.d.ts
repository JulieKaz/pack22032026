import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale it.
 */
export declare const it: Locale;