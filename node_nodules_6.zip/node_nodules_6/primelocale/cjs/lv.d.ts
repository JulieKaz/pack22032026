import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale lv.
 */
export declare const lv: Locale;