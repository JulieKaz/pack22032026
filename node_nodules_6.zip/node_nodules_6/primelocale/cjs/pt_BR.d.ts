import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale pt_BR.
 */
export declare const pt_BR: Locale;