import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale my.
 */
export declare const my: Locale;