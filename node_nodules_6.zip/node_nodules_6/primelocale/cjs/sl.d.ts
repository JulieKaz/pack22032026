import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale sl.
 */
export declare const sl: Locale;