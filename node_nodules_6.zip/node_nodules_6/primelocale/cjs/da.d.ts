import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale da.
 */
export declare const da: Locale;