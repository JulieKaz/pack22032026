import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale uk.
 */
export declare const uk: Locale;