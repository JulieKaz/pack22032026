import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ht.
 */
export declare const ht: Locale;