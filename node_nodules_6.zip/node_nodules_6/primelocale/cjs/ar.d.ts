import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale ar.
 */
export declare const ar: Locale;