import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale bn.
 */
export declare const bn: Locale;