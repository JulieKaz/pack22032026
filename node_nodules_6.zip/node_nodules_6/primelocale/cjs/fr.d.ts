import type { Locale } from "./locale.js";

/**
 * Contains the localized messages for the locale fr.
 */
export declare const fr: Locale;