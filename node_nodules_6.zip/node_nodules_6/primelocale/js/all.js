// @ts-check

import { ar } from "./ar.js";
import { ar_TN } from "./ar_TN.js";
import { bg } from "./bg.js";
import { bn } from "./bn.js";
import { bs } from "./bs.js";
import { ca } from "./ca.js";
import { ckb } from "./ckb.js";
import { cs } from "./cs.js";
import { da } from "./da.js";
import { de } from "./de.js";
import { de_AT } from "./de_AT.js";
import { de_CH } from "./de_CH.js";
import { el } from "./el.js";
import { en } from "./en.js";
import { en_AU } from "./en_AU.js";
import { en_CA } from "./en_CA.js";
import { en_GB } from "./en_GB.js";
import { es } from "./es.js";
import { et } from "./et.js";
import { fa } from "./fa.js";
import { fi } from "./fi.js";
import { fr } from "./fr.js";
import { he } from "./he.js";
import { hi } from "./hi.js";
import { hr } from "./hr.js";
import { ht } from "./ht.js";
import { hu } from "./hu.js";
import { id } from "./id.js";
import { is } from "./is.js";
import { it } from "./it.js";
import { ja } from "./ja.js";
import { kk } from "./kk.js";
import { km } from "./km.js";
import { ko } from "./ko.js";
import { ku } from "./ku.js";
import { ky } from "./ky.js";
import { lt } from "./lt.js";
import { lv } from "./lv.js";
import { ms } from "./ms.js";
import { my } from "./my.js";
import { nb_NO } from "./nb_NO.js";
import { nl } from "./nl.js";
import { pl } from "./pl.js";
import { pt } from "./pt.js";
import { pt_BR } from "./pt_BR.js";
import { ro } from "./ro.js";
import { ru } from "./ru.js";
import { sk } from "./sk.js";
import { sl } from "./sl.js";
import { sq } from "./sq.js";
import { sr_RS } from "./sr_RS.js";
import { sv } from "./sv.js";
import { th } from "./th.js";
import { tl } from "./tl.js";
import { tr } from "./tr.js";
import { uk } from "./uk.js";
import { ur } from "./ur.js";
import { uz } from "./uz.js";
import { vi } from "./vi.js";
import { zh_CN } from "./zh_CN.js";
import { zh_TW } from "./zh_TW.js";

/**
 * An object with all messages for all languages.
 * The key is the language code, the value the messages.
 */
export const all = {
  ar,
  ar_TN,
  "ar-TN": ar_TN,
  bg,
  bn,
  bs,
  ca,
  ckb,
  cs,
  da,
  de,
  de_AT,
  "de-AT": de_AT,
  de_CH,
  "de-CH": de_CH,
  el,
  en,
  en_AU,
  "en-AU": en_AU,
  en_CA,
  "en-CA": en_CA,
  en_GB,
  "en-GB": en_GB,
  es,
  et,
  fa,
  fi,
  fr,
  he,
  hi,
  hr,
  ht,
  hu,
  id,
  is,
  it,
  ja,
  kk,
  km,
  ko,
  ku,
  ky,
  lt,
  lv,
  ms,
  my,
  nb_NO,
  "nb-NO": nb_NO,
  nl,
  pl,
  pt,
  pt_BR,
  "pt-BR": pt_BR,
  ro,
  ru,
  sk,
  sl,
  sq,
  sr_RS,
  "sr-RS": sr_RS,
  sv,
  th,
  tl,
  tr,
  uk,
  ur,
  uz,
  vi,
  zh_CN,
  "zh-CN": zh_CN,
  zh_TW,
  "zh-TW": zh_TW,
};